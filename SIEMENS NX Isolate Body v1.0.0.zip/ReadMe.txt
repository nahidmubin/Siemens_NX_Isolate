SIEMENS NX "Isolate Body"
Version 1.0.0
Created by Nahid Mubin
-------------------------

Installation Procedure for Windows:

1. Download and Extract "SIEMENS NX Isolate Body v1.0.0.zip"

2. Copy the "SIEMENS NX Isolate Body" folder in C drive.
   So the path to the folder will be "C:\SIEMENS NX Isolate Body"

3. Go to the NX installation folder and navigate to "menus" folder.
   If NX is installed in C drive then usually the path will be-
   C:\Program Files\Siemens\NX2206\UGII\menus

4. Open the "custom_dirs.dat" file with notepad or any other editor.
   Paste "C:\SIEMENS NX Isolate Body" at the end of the file and Save it.

5. Start NX. Create a new model file.
   File > New > Model > OK

6. Right Click in the empty space of any Tab or Bar and Click "Customize".

7. Goto Commands > Categories > New Item > Items > New User Command
   Drag "New User Command" and Drop it in the Home Tab's empty space (Right Side).

8. Right Click on the User Command. Add "Isolate Body" to the Name and Change Icon.
   Right Click again Goto Edit Action > Browse.
   Select "Python Files" from the right bottom side drop down menu.
   Goto "Siemens NX Isolate Body" Folder in C Drive and Select "Isolate Body.py" file.
   Press Ok on the Button action window and Close the Customize window.

9. Add an shortcut key to this New "Isolate Body" command. (Optional but Recommended)

10. Open a Part file containing several bodies.

11. Select Feature / Face / Edge / Body and select the "Isolate Body" command or press the shortcut key.
    The intended bodies will be isolated.

12. Select the "Isolate Body" command or press the shortcut key again and the isolation will end.
